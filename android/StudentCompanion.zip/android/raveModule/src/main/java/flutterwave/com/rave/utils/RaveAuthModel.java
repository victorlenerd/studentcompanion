package flutterwave.com.rave.utils;

/**
 * Created by Shittu on 04/02/2017.
 */

public enum RaveAuthModel {
    NOAUTH,
    VBV_SECURECODE,
    ADDRESS_VERIFICATION_SYSTEM,
    PIN,
    RANDOM_DEBIT
}
